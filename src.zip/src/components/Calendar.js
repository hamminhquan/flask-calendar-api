import React, { useState, useEffect } from "react";
import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import Modal from "react-modal";
import io from "socket.io-client";
import "../Calendar.css";

Modal.setAppElement("#root");
const API_BASE = "https://flask-calendar-api-h3tg.onrender.com";
const socket = io(API_BASE, { transports: ["websocket", "polling"] });

const getCurrentDate = () => {
  return new Date().toISOString().split("T")[0];
};

const determineImportanceFrontend = (title) => {
  const emergencyKeywords = ["마감", "진료", "발표", "논문 제출", "기한", "최종"];
  const normalKeywords = ["운동", "공부", "업무", "시험 준비", "회의", "모임"];
  const lowKeywords = ["산책", "여행", "게임", "친구랑 놀기", "영화 보기"];

  for (let keyword of emergencyKeywords) {
    if (title.includes(keyword)) return "긴급";
  }
  for (let keyword of normalKeywords) {
    if (title.includes(keyword)) return "보통";
  }
  for (let keyword of lowKeywords) {
    if (title.includes(keyword)) return "없음";
  }
  return "자동 판단";
};

const Calendar = () => {
  const [events, setEvents] = useState([]);
  const [modalType, setModalType] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [isMultiDay, setIsMultiDay] = useState(false);
  const [viewMode, setViewMode] = useState("event"); // ✅ 일정 추가 / 뉴스 모드 전환
  const [newsKeywords, setNewsKeywords] = useState(""); // 키워드 상태
  const [savedKeywords, setSavedKeywords] = useState(""); // 저장된 키워드 상태
  const [newsArticles, setNewsArticles] = useState([]); // // 뉴스 데이터
  const [newEvent, setNewEvent] = useState({
    title: "",
    date: "",
    time: "",
    endDate: "",
    importance: "자동 판단",
  });

  // 키워드 저장 함수
const fetchKeywords = async () => {
  try {
    console.log("🔍 키워드 불러오는 중...");
    const response = await fetch(`${API_BASE}/get_keywords`);

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();
    if (data.keywords) {
      setNewsKeywords(data.keywords);
      setSavedKeywords(data.keywords); // ✅ 초기 키워드 저장
      fetchNews(data.keywords); // ✅ 초기 뉴스 자동 로드
    }
  } catch (error) {
    console.error("❌ 키워드 불러오기 오류:", error);
  }
};

const saveKeywords = async (newKeyword) => {
  setSavedKeywords(newKeyword);
  setNewsKeywords(newKeyword);

  localStorage.setItem("savedKeywords", newKeyword); // 🔹 localStorage에 저장 (새로고침 방지)

  try {
    await fetch(`${API_BASE}/save_keywords`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ keywords: newKeyword }),
    });

    console.log("✅ 키워드 저장 완료:", newKeyword);
    fetchNews(newKeyword); // ✅ 키워드 저장 후 뉴스 업데이트
  } catch (error) {
    console.error("❌ 키워드 저장 오류:", error);
  }
};

 // 키워드가 저장되면 자동으로 뉴스 가져오기
const fetchNews = async (keywords) => {
  try {
    console.log("📰 뉴스 자동 업데이트 실행... 키워드:", keywords);
    
    const response = await fetch(`${API_BASE}/fetch_news`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ keywords }),
    });

    const data = await response.json();
    console.log("📢 API 응답 데이터:", data.news);  // 🔥 응답 확인용 로그

    if (response.ok && data.news.length > 0) {
      setNewsArticles(data.news.slice(0, 5)); // 🔹 최신 뉴스 5개만 표시
      console.log("✅ 뉴스 업데이트 완료!", data.news.slice(0, 5));
    } else {
      console.error("❌ 뉴스 검색 실패 또는 결과 없음:", data.error);
    }
  } catch (error) {
    console.error("❌ 뉴스 불러오기 오류:", error);
  }
};


useEffect(() => {
  console.log("🔍 현재 뉴스 상태 (렌더링됨):", newsArticles);
}, [newsArticles]);

useEffect(() => {
  console.log("🔎 현재 뉴스 상태:", newsArticles); // 🔥 뉴스 데이터 확인
}, [newsArticles]);

// ✅ 키워드 불러오기 (페이지 로드 시 실행)
useEffect(() => {
  const storedKeywords = localStorage.getItem("savedKeywords");

  if (storedKeywords) {
    console.log("🔄 저장된 키워드 불러오기:", storedKeywords);
    setSavedKeywords(storedKeywords);
    setNewsKeywords(storedKeywords);
    fetchNews(storedKeywords);
  } else {
    console.log("❌ 저장된 키워드 없음, 기본값 설정 필요");
  }
}, []);


useEffect(() => {
  if (typeof savedKeywords === "undefined") {
    console.error("❌ savedKeywords가 정의되지 않음");
    return;
  }

  const updateNewsDaily = setInterval(() => {
    if (savedKeywords) {
      console.log("🔄 하루 간격으로 자동 뉴스 업데이트 실행... 키워드:", savedKeywords);
      fetchNews(savedKeywords);
    }
  }, 86400000); // 24시간 = 86400000 밀리초

  return () => clearInterval(updateNewsDaily); // ✅ 메모리 누수 방지
}, [savedKeywords]); // 🔹 키워드가 바뀌면 즉시 실행 & 매일 자동 업데이트





useEffect(() => {
  const updateNewsDaily = setInterval(() => {
    if (savedKeywords) {
      console.log("🔄 하루 간격으로 자동 뉴스 업데이트 실행... 키워드:", savedKeywords);
      fetchNews(savedKeywords);
    }
  }, 86400000); // 24시간 = 86400000 밀리초

  return () => clearInterval(updateNewsDaily); // ✅ 메모리 누수 방지
}, [savedKeywords]); // ✅ 오류 수정된 코드



  const fetchEvents = async () => {
    try {
      const response = await fetch(`${API_BASE}/events`);
      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
      const data = await response.json();
      if (!Array.isArray(data)) {
        console.error("❌ 일정 데이터가 배열이 아님:", data);
        return;
      }
      setEvents(data);
    } catch (error) {
      console.error("❌ 일정 불러오기 오류:", error);
    }
  };

  useEffect(() => {
    fetchEvents();
    socket.on("event_reminder", (data) => handleNotification(data));
    socket.on("refresh_events", fetchEvents);
    return () => {
      socket.off("event_reminder");
      socket.off("refresh_events");
    };
  }, []);

 
  const handleNotification = (data) => {
    const today = getCurrentDate();
    
    if (data.date < today) {
        console.log(`🚫 과거 일정 (${data.date}) - 알림을 보내지 않음`);
        return;
    }

    if (data.endDate) {
        if (data.date === data.endDate) {
            sendNotification(data);
        } else {
            console.log(`🚫 연속 일정 (${data.date}) - 마지막 날(${data.endDate})이 아니므로 알림 안 보냄`);
        }
    } else {
        sendNotification(data);
    }
  };


  const sendNotification = (data) => {
    if (Notification.permission === "granted") {
      new Notification(`${data.type}`, {
        body: `${data.title} 일정이 ${data.date} ${data.time}에 있습니다!`,
        icon: "/calendar-icon.png",
      });
    }
  };

  const handleSaveEvent = async () => {
    if (!newEvent.title || !newEvent.date || !newEvent.time) {
      alert("제목, 날짜, 시간을 입력하세요.");
      return;
    }

   const formattedEndDate = isMultiDay ? newEvent.endDate : "";  // ✅ 하루 추가하는 부분 삭제!


    const eventToSend = {
      ...newEvent,
      importance: newEvent.importance === "자동 판단" ? determineImportanceFrontend(newEvent.title) : newEvent.importance,
      endDate: isMultiDay ? formattedEndDate : "",
    };

    try {
      const method = modalType === "edit" ? "PUT" : "POST";
      const url = modalType === "edit" ? `${API_BASE}/events/${selectedEvent.id}` : `${API_BASE}/events`;

      const response = await fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(eventToSend),
      });

      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

      fetchEvents();
      closeModal();
    } catch (error) {
      console.error("❌ 저장 오류:", error);
      alert("일정 저장 중 오류가 발생했습니다.");
    }
  };

  const handleDeleteEvent = async () => {
    try {
      await fetch(`${API_BASE}/events/${selectedEvent.id}`, { method: "DELETE" });
      fetchEvents();
      closeModal();
    } catch (error) {
      console.error("❌ 일정 삭제 오류:", error);
    }
  };

  const closeModal = () => {
    setModalType(null);
    setSelectedEvent(null);
    setIsMultiDay(false);
    setViewMode("event"); // ✅ 기본 모드 일정 추가로 리셋
  };

  const handleEventClick = (clickInfo) => {
    const event = events.find(event => event.id === parseInt(clickInfo.event.id));
    if (event) {
      setSelectedEvent(event);
      setNewEvent({
        title: event.title,
        date: event.date,
        time: event.time,
        endDate: event.endDate || "",
        importance: event.importance || "자동 판단",
      });
      setIsMultiDay(!!event.endDate);
      setModalType("edit");
    }
  };

  return (
    <div className="calendar-container">
      <h1>📅 스마트 달력</h1>
      <button className="add-event-button" onClick={() => setModalType("add")}>+ 일정 추가</button>

      <div className="calendar-wrapper">
        <FullCalendar
          plugins={[dayGridPlugin, interactionPlugin]}
          initialView="dayGridMonth"
          events={events.map(event => ({
            id: event.id.toString(),
            title: `${event.title} (${event.time})`,
            start: event.date,
            end: event.endDate ? new Date(new Date(event.endDate).setDate(new Date(event.endDate).getDate() + 1)).toISOString().split("T")[0] : event.date
          }))}
          dateClick={(arg) => {
            setNewEvent({ title: "", date: arg.dateStr, time: "", endDate: "", importance: "자동 판단" });
            setModalType("add");
          }}
          eventClick={handleEventClick}
        />
      </div>

      <Modal
  isOpen={modalType !== null}
  onRequestClose={closeModal}
  className={`modal ${viewMode === "news" ? "news-mode" : ""}`} // ✅ 뉴스 모드일 때만 확장
>
  <div className="modal-header">
    <h2>{modalType === "edit" ? "일정 수정" : "일정 추가"}</h2>

    {/* ✅ 일정 추가 | 뉴스 버튼 (오른쪽 상단) */}
    <div className="view-mode-buttons">
      <button
        onClick={() => setViewMode("event")}
        className={`tab-button ${viewMode === "event" ? "active" : ""}`}
      >
        일정 추가
      </button>
      <button
        onClick={() => setViewMode("news")}
        className={`tab-button ${viewMode === "news" ? "active" : ""}`}
      >
        뉴스
      </button>
    </div>
  </div>

  {/* ✅ 일정 추가 모드 */}
  {viewMode === "event" && (
    <>
      <input type="text" placeholder="일정 제목" value={newEvent.title} onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })} />
      <input type="date" value={newEvent.date} onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })} />
      <input type="time" value={newEvent.time} onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })} />

      <div className="importance-row">
        <select value={newEvent.importance} onChange={(e) => setNewEvent({ ...newEvent, importance: e.target.value })}>
          <option value="자동 판단">자동 판단</option>
          <option value="없음">없음</option>
          <option value="보통">보통</option>
          <option value="긴급">긴급</option>
        </select>
        <label className="checkbox-label">
          <input type="checkbox" checked={isMultiDay} onChange={() => setIsMultiDay(!isMultiDay)} /> 종료 날짜
        </label>
      </div>

      {isMultiDay && <input type="date" value={newEvent.endDate} onChange={(e) => setNewEvent({ ...newEvent, endDate: e.target.value })} />}
      <button className="save-button" onClick={handleSaveEvent}>저장</button>
      {modalType === "edit" && <button className="delete-button" onClick={handleDeleteEvent}>삭제</button>}
      <button className="close-button" onClick={closeModal}>닫기</button>
    </>
  )}

  {/* ✅ 뉴스 추가 모드 */}
  {viewMode === "news" && (
    <div className="news-section">

      <p>🔍 관심 있는 뉴스 키워드를 입력하세요:</p>
      <input
         type="text"
         placeholder="예: 인공지능, 경제, 건강"
         value={newsKeywords}
             onChange={(e) => setNewsKeywords(e.target.value ? e.target.value.trim() : "")} 
       />

      <button className="save-button" onClick={() => saveKeywords(newsKeywords)}>키워드 저장</button>

      {/* ✅ 검색된 뉴스 표시 */}
      {newsArticles.length > 0 && (
        <div className="news-container">
          <h3>🔍 검색된 뉴스</h3>
          <ul>
            {newsArticles.map((article, index) => (
              <li key={index}>
                <a href={article.url} target="_blank" rel="noopener noreferrer">
                  {article.title}
                </a>
                <br />
                <small>{article.date}</small>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  )}
</Modal>
    </div>
  );
};

export default Calendar;

