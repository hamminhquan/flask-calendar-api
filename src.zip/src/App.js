import React from "react";
import Calendar from "./components/Calendar";

function App() {
  return (
    <div>
      <h1>🗓 스마트 달력</h1>
      <Calendar />
    </div>
  );
}

export default App;
