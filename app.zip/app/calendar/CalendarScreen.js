import React, { useState, useEffect } from "react";
import { View, Text, Modal, TextInput, Button, TouchableOpacity, StyleSheet, FlatList, ScrollView } from "react-native";
import { Calendar } from "react-native-calendars";
import axios from "axios";

const API_BASE = "https://flask-calendar-api-h3tg.onrender.com";

const CalendarScreen = () => {
  const [selectedDate, setSelectedDate] = useState("");
  const [eventText, setEventText] = useState("");
  const [events, setEvents] = useState({});
  const [modalVisible, setModalVisible] = useState(false);
  const [editingEvent, setEditingEvent] = useState(false);
  const [eventId, setEventId] = useState(null);
  const [doubleClickTimeout, setDoubleClickTimeout] = useState(null); // 더블 클릭 타임아웃

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await axios.get(`${API_BASE}/events`);
      const formattedEvents = response.data.reduce((acc, event) => {
        acc[event.date] = { marked: true, dotColor: "blue", event };
        return acc;
      }, {});
      setEvents(formattedEvents);
    } catch (error) {
      console.error("일정 불러오기 오류:", error);
    }
  };

  const handleDayPress = (day) => {
    const currentDate = day.dateString;
    setSelectedDate(currentDate);

    // 더블 클릭 구현
    if (doubleClickTimeout) {
      clearTimeout(doubleClickTimeout); // 타임아웃 초기화
      setDoubleClickTimeout(null);

      if (!events[currentDate]) {
        setEventText(""); // 일정이 없으면 일정 추가 모달 열기
        setEditingEvent(false);
        setEventId(null);
        setModalVisible(true);
      }
      return;
    }

    // 첫 번째 클릭으로 선택된 날짜에 대한 일정 로딩
    if (events[currentDate]) {
      setEventText(events[currentDate].event.title);
      setEditingEvent(true);
      setEventId(events[currentDate].event.id);
    } else {
      setEventText(""); // 일정이 없으면 입력 창 비우기
      setEditingEvent(false);
      setEventId(null);
    }

    setDoubleClickTimeout(setTimeout(() => {
      setDoubleClickTimeout(null);
    }, 300)); // 300ms 내에 더블 클릭으로 인식
  };

  const saveEvent = async () => {
    if (!selectedDate || !eventText) return;
    try {
      if (editingEvent) {
        await axios.put(`${API_BASE}/events/${eventId}`, {
          title: eventText,
          date: selectedDate,
          time: "00:00",
        });
      } else {
        await axios.post(`${API_BASE}/events`, {
          title: eventText,
          date: selectedDate,
          time: "00:00",
        });
      }
      fetchEvents();
      setModalVisible(false);
    } catch (error) {
      console.error("일정 저장 오류:", error);
    }
  };

  const deleteEvent = async () => {
    try {
      await axios.delete(`${API_BASE}/events/${eventId}`);
      fetchEvents();
      setModalVisible(false);
    } catch (error) {
      console.error("일정 삭제 오류:", error);
    }
  };

  const handleAddEventClick = () => {
    setEventText(""); // 일정 입력창 초기화
    setEditingEvent(false);
    setEventId(null);
    setModalVisible(true);
  };

  const handleEventClick = (eventId, eventTitle) => {
    setEditingEvent(true);
    setEventText(eventTitle);
    setEventId(eventId);
    setModalVisible(true);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>📅 스마트 캘린더</Text>
      <View style={styles.calendarContainer}>
        <Calendar
          onDayPress={handleDayPress}
          markedDates={events}
          style={{ minHeight: 400 }} // 캘린더 높이 확보
        />
      </View>

      {/* 하단 일정 리스트 */}
      <ScrollView contentContainerStyle={{ flexGrow: 1, minHeight: 100, paddingBottom: 120 }}>
        <FlatList
          data={events[selectedDate] ? [events[selectedDate].event] : []}
          keyExtractor={(item) => item.id.toString()}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={() => handleEventClick(item.id, item.title)}>
              <View style={styles.eventItem}>
                <Text>{item.title}</Text>
              </View>
            </TouchableOpacity>
          )}
        />
      </ScrollView>

      {/* 일정 추가/수정 Modal */}
      <Modal animationType="slide" transparent={true} visible={modalVisible} onRequestClose={() => setModalVisible(false)}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{editingEvent ? "일정 수정" : "일정 추가"}</Text>
            <Text style={styles.modalDate}>날짜: {selectedDate}</Text>
            <TextInput style={styles.input} placeholder="일정 입력" value={eventText} onChangeText={setEventText} />
            <View style={styles.buttonRow}>
              <Button title="저장" onPress={saveEvent} />
              {editingEvent && <Button title="삭제" color="red" onPress={deleteEvent} />}
              <Button title="닫기" color="gray" onPress={() => setModalVisible(false)} />
            </View>
          </View>
        </View>
      </Modal>

      {/* 일정 추가 버튼 */}
      <TouchableOpacity style={styles.addButton} onPress={handleAddEventClick}>
        <Text style={styles.addButtonText}>+</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
  },
  calendarContainer: {
    flexShrink: 1,
    marginBottom: 10,
  },
  eventItem: {
    padding: 10,
    backgroundColor: "#f9f9f9",
    marginBottom: 5,
    borderRadius: 5,
  },
  modalContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0, 0, 0, 0.5)",
  },
  modalContent: {
    width: 300,
    padding: 20,
    backgroundColor: "#fff",
    borderRadius: 10,
    alignItems: "center",
  },
  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-around",
    width: "100%",
  },
  addButton: {
    position: "absolute",
    right: 20,
    bottom: 20,
    backgroundColor: "#00f",
    width: 60,
    height: 60,
    borderRadius: 30,
    justifyContent: "center",
    alignItems: "center",
    zIndex: 100, // 항상 위에 있도록 설정
  },
  addButtonText: {
    fontSize: 30,
    color: "#fff",
  },
});

export default CalendarScreen;
